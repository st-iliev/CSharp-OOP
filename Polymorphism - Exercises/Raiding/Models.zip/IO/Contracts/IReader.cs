﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exeptions
{
    public static class ExceptionMessage
    {
        public const string message = "{0} does not eat {1}!";
    }
}
